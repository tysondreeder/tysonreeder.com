
<div class="header-container">
<header>
    <div class="name-container">
      <a href="/" class="name">Tyson Reeder
        <span class="sub-text">UX Designer / Visual Designer</span>
      </a>
    </div>
    <div class="nav">
      <a href="/" class="nav-item u-mR10 <?if($page=="work"){?>active<?}?>">Work
      </a>
      <a href="/about.php" class="nav-item <?if($page=="about"){?>active<?}?>">About
      </a>
    </div>
</header>
</div>